package com.example.volkeymap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView

class KeyMapService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: KeyMapService? = null
    }

    private var wm: WindowManager? = null
    private val markers = mutableMapOf<String, Pair<View, WindowManager.LayoutParams>>()
    private var saveBtn: View? = null
    private var size = 0

    override fun onServiceConnected() {
        instance = this
    }

    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (!Store.isActive(this) || markers.isNotEmpty()) return false
        val key = when (e.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> "up"
            KeyEvent.KEYCODE_VOLUME_DOWN -> "down"
            else -> return false
        }
        if (e.action == KeyEvent.ACTION_DOWN) {
            val p = Store.getPoint(this, key)
            tap(p.x, p.y)
        }
        return true // consume: no cambia el volumen
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 40))
            .build()
        dispatchGesture(g, null, null)
    }

    // ---------- Editor: puntos arrastrables ----------

    fun showEditor() {
        if (markers.isNotEmpty()) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        this.wm = wm
        val d = resources.displayMetrics.density
        size = (64 * d).toInt()

        listOf("up" to "VOL +", "down" to "VOL -").forEach { (key, label) ->
            val c = Store.getPoint(this, key)
            val v = TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xCC3F51B5.toInt())
                }
            }
            val lp = overlayParams(size, size).apply {
                x = (c.x - size / 2f).toInt()
                y = (c.y - size / 2f).toInt()
            }
            v.setOnTouchListener(object : View.OnTouchListener {
                var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
                override fun onTouch(view: View, ev: MotionEvent): Boolean {
                    when (ev.action) {
                        MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = ev.rawX; ty = ev.rawY }
                        MotionEvent.ACTION_MOVE -> {
                            lp.x = sx + (ev.rawX - tx).toInt()
                            lp.y = sy + (ev.rawY - ty).toInt()
                            wm.updateViewLayout(view, lp)
                        }
                    }
                    return true
                }
            })
            wm.addView(v, lp)
            markers[key] = v to lp
        }

        val btn = TextView(this).apply {
            text = "✔ Guardar"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding((20 * d).toInt(), (10 * d).toInt(), (20 * d).toInt(), (10 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 40f
                setColor(0xFF2E7D32.toInt())
            }
            setOnClickListener { hideEditor(true) }
        }
        val blp = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
            .apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = (48 * d).toInt() }
        wm.addView(btn, blp)
        saveBtn = btn
    }

    fun hideEditor(save: Boolean) {
        val wm = this.wm ?: return
        markers.forEach { (key, pair) ->
            val (v, lp) = pair
            if (save) Store.setPoint(this, key, lp.x + size / 2f, lp.y + size / 2f)
            wm.removeView(v)
        }
        markers.clear()
        saveBtn?.let { wm.removeView(it) }
        saveBtn = null
    }

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        hideEditor(false)
        instance = null
        super.onDestroy()
    }
}
