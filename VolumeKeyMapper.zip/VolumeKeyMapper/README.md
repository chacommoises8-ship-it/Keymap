# Volume Key Mapper

1. Abre la carpeta en Android Studio (Hedgehog o más nuevo) y espera el Gradle Sync.
2. Conecta tu celular (depuración USB) y pulsa Run.
3. En la app: activa el servicio en Accesibilidad.
   Si Android lo bloquea: Ajustes > Apps > Volume Key Mapper > menú ⋮ > "Permitir ajustes restringidos".
4. Pulsa "Colocar botones", abre tu juego, arrastra VOL+ y VOL- a donde quieras que toque y pulsa "Guardar".
5. Listo: VOL+ y VOL- tocan esos puntos (con la pantalla encendida).
