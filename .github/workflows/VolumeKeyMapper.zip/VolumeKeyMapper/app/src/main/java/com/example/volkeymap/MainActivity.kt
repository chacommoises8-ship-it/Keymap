package com.example.volkeymap

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, pad) }
        root.addView(status)

        root.addView(button("1. Activar servicio de accesibilidad") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        root.addView(button("2. Colocar botones sobre el juego") {
            val s = KeyMapService.instance
            if (s == null) {
                Toast.makeText(this, "Primero activa el servicio (paso 1)", Toast.LENGTH_LONG).show()
            } else {
                s.showEditor()
                Toast.makeText(this, "Abre tu juego, arrastra VOL+ y VOL- y pulsa Guardar", Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            }
        })

        root.addView(Switch(this).apply {
            text = "Mapeo activo"
            textSize = 16f
            setPadding(0, pad, 0, 0)
            isChecked = Store.isActive(this@MainActivity)
            setOnCheckedChangeListener { _, checked -> Store.setActive(this@MainActivity, checked) }
        })

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (KeyMapService.instance != null)
            "Servicio: ACTIVO ✅" else "Servicio: apagado ❌ (actívalo en Accesibilidad)"
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }
}
