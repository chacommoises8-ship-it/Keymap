package com.example.volkeymap

import android.content.Context
import android.graphics.PointF

/** Guarda las posiciones de los toques y si el mapeo está activo. */
object Store {
    private fun p(c: Context) = c.getSharedPreferences("keymap", Context.MODE_PRIVATE)

    fun getPoint(c: Context, key: String): PointF {
        val dm = c.resources.displayMetrics
        val defY = dm.heightPixels * if (key == "up") 0.4f else 0.6f
        return PointF(
            p(c).getFloat("${key}_x", dm.widthPixels * 0.85f),
            p(c).getFloat("${key}_y", defY)
        )
    }

    fun setPoint(c: Context, key: String, x: Float, y: Float) {
        p(c).edit().putFloat("${key}_x", x).putFloat("${key}_y", y).apply()
    }

    fun isActive(c: Context) = p(c).getBoolean("active", true)
    fun setActive(c: Context, v: Boolean) = p(c).edit().putBoolean("active", v).apply()
}
